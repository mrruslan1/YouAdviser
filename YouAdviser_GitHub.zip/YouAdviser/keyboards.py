from aiogram.types import (
    ReplyKeyboardMarkup,
    KeyboardButton,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
)


def main_menu() -> ReplyKeyboardMarkup:
    """Главное меню: короткие подписи хорошо помещаются на телефоне."""
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="🧭 Подобрать профессию"), KeyboardButton(text="💬 Поговорить")],
            [KeyboardButton(text="📚 Каталог профессий"), KeyboardButton(text="🧩 Направления")],
            [KeyboardButton(text="👤 Мой профиль"), KeyboardButton(text="⭐ Избранное")],
            [KeyboardButton(text="🗺 План развития"), KeyboardButton(text="⚖️ Сравнить")],
            [KeyboardButton(text="🎲 Случайная профессия"), KeyboardButton(text="❓ Помощь")],
        ],
        resize_keyboard=True,
        input_field_placeholder="Выбери раздел или задай вопрос…",
    )


def chat_menu() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="🧭 Подобрать профессию"), KeyboardButton(text="📚 Каталог профессий")],
            [KeyboardButton(text="⏹ Завершить диалог"), KeyboardButton(text="⬅️ Главное меню")],
        ],
        resize_keyboard=True,
        input_field_placeholder="Напиши, что тебя интересует…",
    )


def choice_keyboard(options):
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=label, callback_data=f"answer:{value}")]
            for label, value in options
        ]
    )


def category_keyboard(categories):
    rows = []
    for index in range(0, len(categories), 2):
        row = [
            InlineKeyboardButton(text=label, callback_data=f"cat:{slug}")
            for label, slug in categories[index:index + 2]
        ]
        rows.append(row)
    rows.append([InlineKeyboardButton(text="📚 Все профессии", callback_data="cat:all")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def profession_keyboard(profession_id: int, is_favorite: bool = False):
    favorite_label = "✅ Уже в избранном" if is_favorite else "⭐ В избранное"
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=favorite_label, callback_data=f"fav:{profession_id}")],
            [InlineKeyboardButton(text="🗺 План первых шагов", callback_data=f"plan:{profession_id}")],
            [InlineKeyboardButton(text="⚖️ Сравнить", callback_data=f"cmp:{profession_id}")],
        ]
    )


def remove_favorite_keyboard(profession_id: int):
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="❌ Убрать из избранного", callback_data=f"unfav:{profession_id}")]
        ]
    )


def pagination_keyboard(slug: str, offset: int, total: int, page_size: int = 5):
    buttons = []
    if offset > 0:
        buttons.append(InlineKeyboardButton(text="⬅️ Назад", callback_data=f"list:{slug}:{max(0, offset-page_size)}"))
    if offset + page_size < total:
        buttons.append(InlineKeyboardButton(text="Вперёд ➡️", callback_data=f"list:{slug}:{offset+page_size}"))
    rows = [buttons] if buttons else []
    rows.append([InlineKeyboardButton(text="🧩 К направлениям", callback_data="categories")])
    return InlineKeyboardMarkup(inline_keyboard=rows)
