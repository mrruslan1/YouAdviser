# Security

- Never commit `.env`, API keys, Telegram bot tokens, local database files, or logs.
- Configure credentials only in your local `.env` file, using `.env.example` as a template.
- `OWNER_TELEGRAM_ID` is an optional private configuration value used to restrict the owner panel. Keep it out of public commits.
- If a credential was committed or shared accidentally, revoke or rotate it with the provider before continuing to use the bot.
- Do not publish a database containing real users' profiles, messages, or saved professions.
