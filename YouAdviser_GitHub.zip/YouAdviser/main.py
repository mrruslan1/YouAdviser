import asyncio
import logging
import os

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import BotCommand
from dotenv import load_dotenv

# .env загружается до импорта модулей, которые читают настройки.
load_dotenv()

from database import init_db
from handlers import router
from ai_service import is_groq_configured


async def main():
    token = os.getenv("BOT_TOKEN")
    if not token or token == "ВСТАВЬТЕ_ТОКЕН_ОТ_BOTFATHER":
        raise RuntimeError("Укажите настоящий BOT_TOKEN в файле .env")

    await init_db()
    bot = Bot(token=token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher(storage=MemoryStorage())
    dp.include_router(router)

    await bot.set_my_commands([
        BotCommand(command="start", description="Открыть YouAdviser"),
        BotCommand(command="menu", description="Главное меню"),
        BotCommand(command="test", description="Подобрать профессию"),
        BotCommand(command="chat", description="Поговорить с ИИ-компаньоном"),
        BotCommand(command="memory", description="Посмотреть долговременную память"),
        BotCommand(command="remember", description="Сохранить факт в память"),
        BotCommand(command="forget", description="Удалить долговременную память"),
        BotCommand(command="clearhistory", description="Очистить историю диалога"),
        BotCommand(command="professions", description="Каталог профессий"),
        BotCommand(command="profile", description="Мой профиль"),
        BotCommand(command="favorites", description="Избранные профессии"),
        BotCommand(command="cancel", description="Отменить текущее действие"),
        BotCommand(command="admin", description="Панель владельца"),
    ])

    if is_groq_configured():
        logging.info("Groq AI настроен и будет использоваться в режиме диалога")
    else:
        logging.warning("GROQ_API_KEY не задан: бот запущен в локальном режиме без генеративного ИИ")

    logging.info("YouAdviser запущен")
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        await bot.session.close()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(main())
