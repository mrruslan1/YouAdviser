"""Локальные настройки ИИ для панели владельца.

Файл настроек создаётся автоматически рядом с проектом. Секреты сюда не записываются.
"""
from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any

SETTINGS_PATH = Path(__file__).with_name("ai_settings.json")
DEFAULTS: dict[str, Any] = {
    "model": "",
    "prompts": {
        "chat": "",
        "career": "",
        "recommendations": "",
        "photo": "",
        "plan": "",
        "compare": "",
    },
}


def load_settings() -> dict[str, Any]:
    """Читает настройки и безопасно дополняет отсутствующие значения."""
    data: dict[str, Any] = {}
    try:
        if SETTINGS_PATH.exists():
            with SETTINGS_PATH.open("r", encoding="utf-8") as file:
                loaded = json.load(file)
            if isinstance(loaded, dict):
                data = loaded
    except (OSError, json.JSONDecodeError):
        data = {}

    prompts = dict(DEFAULTS["prompts"])
    stored_prompts = data.get("prompts", {})
    if isinstance(stored_prompts, dict):
        for key in prompts:
            value = stored_prompts.get(key, "")
            prompts[key] = value if isinstance(value, str) else ""

    model = data.get("model", "")
    return {
        "model": model if isinstance(model, str) else "",
        "prompts": prompts,
    }


def save_settings(updates: dict[str, Any]) -> dict[str, Any]:
    """Обновляет только переданные поля и атомарно сохраняет JSON."""
    if not isinstance(updates, dict):
        raise TypeError("updates должен быть словарём")
    current = load_settings()

    if "model" in updates:
        model = updates["model"]
        current["model"] = model.strip()[:160] if isinstance(model, str) else ""

    if "prompts" in updates:
        supplied = updates["prompts"]
        if isinstance(supplied, dict):
            for key in current["prompts"]:
                if key in supplied:
                    value = supplied[key]
                    current["prompts"][key] = value[:5000] if isinstance(value, str) else ""

    SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary_name = tempfile.mkstemp(
        prefix="ai_settings_", suffix=".tmp", dir=str(SETTINGS_PATH.parent)
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as file:
            json.dump(current, file, ensure_ascii=False, indent=2)
            file.flush()
            os.fsync(file.fileno())
        os.replace(temporary_name, SETTINGS_PATH)
    finally:
        if os.path.exists(temporary_name):
            os.unlink(temporary_name)
    return current


def get_prompt(mode: str) -> str:
    return load_settings()["prompts"].get(mode, "")
