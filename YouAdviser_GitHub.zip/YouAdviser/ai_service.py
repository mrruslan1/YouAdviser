"""Асинхронная интеграция CareerGuide с Groq Chat Completions API."""

import logging
import os

import httpx

from ai_settings import load_settings

logger = logging.getLogger(__name__)

GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions"
DEFAULT_GROQ_MODEL = "openai/gpt-oss-120b"
DEFAULT_GROQ_VISION_MODEL = "qwen/qwen3.8-27b"


class GroqError(RuntimeError):
    """Ошибка конфигурации или ответа Groq API."""


class GroqNotConfigured(GroqError):
    """API-ключ Groq не задан."""


def is_groq_configured() -> bool:
    return bool(os.getenv("GROQ_API_KEY", "").strip())


def _api_error_message(status_code: int) -> str:
    if status_code == 401:
        return "Groq отклонил API-ключ (401). Проверьте GROQ_API_KEY в .env."
    if status_code == 403:
        return "У проекта нет доступа к выбранной модели Groq (403). Проверьте GROQ_MODEL и права проекта."
    if status_code == 404:
        return "Модель Groq не найдена (404). Проверьте значение GROQ_MODEL."
    if status_code == 429:
        return "Groq временно ограничил запросы (429). Попробуйте немного позже."
    if status_code >= 500:
        return f"Сервис Groq временно недоступен ({status_code})."
    return f"Groq вернул ошибку HTTP {status_code}."


def _build_completion_payload(model: str, messages: list[dict]) -> dict:
    """Собирает запрос с достаточным лимитом для длинных ответов и полного кода."""
    try:
        max_tokens = int(os.getenv("GROQ_MAX_COMPLETION_TOKENS", "8192"))
    except ValueError:
        max_tokens = 8192
    max_tokens = min(32768, max(1024, max_tokens))

    payload = {
        "model": model,
        "messages": messages,
        "temperature": 0.3,
        "max_completion_tokens": max_tokens,
        "stream": False,
    }
    # GPT-OSS supports explicit reasoning-effort control on Groq.
    if model.startswith("openai/gpt-oss-"):
        effort = os.getenv("GROQ_REASONING_EFFORT", "high").strip().lower()
        payload["reasoning_effort"] = effort if effort in {"low", "medium", "high"} else "high"
        # Use the model's reasoning internally without exposing private reasoning tokens to users.
        payload["reasoning_format"] = "hidden"
    return payload


async def generate_reply(messages: list[dict], model_override: str | None = None) -> str:
    """Отправляет историю диалога (в том числе изображения) в Groq и возвращает текст ответа."""
    api_key = os.getenv("GROQ_API_KEY", "").strip()
    if not api_key:
        raise GroqNotConfigured("GROQ_API_KEY не задан в .env")

    settings = load_settings()
    configured_model = settings.get("model") or os.getenv("GROQ_MODEL", DEFAULT_GROQ_MODEL)
    model = model_override or str(configured_model).strip() or DEFAULT_GROQ_MODEL
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(60.0, connect=10.0)) as client:
            response = await client.post(
                GROQ_API_URL,
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json",
                },
                json=_build_completion_payload(model, messages),
            )
    except httpx.TimeoutException as exc:
        raise GroqError("Истекло время ожидания ответа Groq.") from exc
    except httpx.RequestError as exc:
        raise GroqError("Не удалось подключиться к Groq API.") from exc

    if response.is_error:
        logger.warning("Groq API returned HTTP %s", response.status_code)
        raise GroqError(_api_error_message(response.status_code))

    try:
        payload = response.json()
        content = payload["choices"][0]["message"]["content"]
    except (ValueError, KeyError, IndexError, TypeError) as exc:
        raise GroqError("Groq вернул ответ в неожиданном формате.") from exc

    if isinstance(content, list):
        # Некоторые модели возвращают составное содержимое вместо простой строки.
        content = "\n".join(
            part.get("text", "") for part in content
            if isinstance(part, dict) and part.get("type") == "text"
        )

    if not isinstance(content, str) or not content.strip():
        raise GroqError("Groq вернул пустой ответ.")

    return content.strip()


async def extract_durable_memories(user_text: str, assistant_text: str) -> list[dict[str, str]]:
    """Извлекает только явно полезные долгосрочные факты; при ошибке возвращает []."""
    api_key = os.getenv("GROQ_API_KEY", "").strip()
    if not api_key:
        return []
    model = os.getenv("GROQ_MODEL", DEFAULT_GROQ_MODEL).strip() or DEFAULT_GROQ_MODEL
    prompt = (
        "Выдели из диалога только устойчивые, полезные для будущей персонализации факты о пользователе. "
        "Не сохраняй разовые задачи, догадки, чужие сведения, пароли, ключи, адреса, контакты, "
        "финансовые реквизиты, медицинские сведения, политические взгляды, религию, сексуальную жизнь "
        "или другие чувствительные данные. Не делай выводов, которых пользователь прямо не сообщил. "
        "Верни строго JSON-массив объектов вида {\\\"content\\\":\\\"короткий факт\\\",\\\"category\\\":\\\"preference|goal|project|fact\\\"}. "
        "Максимум 3 факта, каждый до 180 символов. Если сохранять нечего — [].\n\n"
        f"Сообщение пользователя: {user_text[:2500]}\nОтвет ассистента: {assistant_text[:2500]}"
    )
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(20.0, connect=8.0)) as client:
            response = await client.post(
                GROQ_API_URL,
                headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                json={"model": model, "messages": [{"role": "user", "content": prompt}],
                      "temperature": 0, "max_completion_tokens": 350, "stream": False},
            )
        if response.is_error:
            return []
        raw = response.json()["choices"][0]["message"]["content"]
        if isinstance(raw, list):
            raw = "".join(x.get("text", "") for x in raw if isinstance(x, dict))
        import json
        import re
        match = re.search(r"\[.*\]", str(raw), re.S)
        data = json.loads(match.group(0)) if match else []
        if not isinstance(data, list):
            return []
        return [x for x in data[:3] if isinstance(x, dict) and isinstance(x.get("content"), str)]
    except Exception as exc:
        logger.info("Не удалось извлечь долговременную память: %s", exc)
        return []
