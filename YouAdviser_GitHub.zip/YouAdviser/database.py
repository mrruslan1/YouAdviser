import json

from sqlalchemy import String, Integer, Text, ForeignKey, select, DateTime, delete
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

from config import DATABASE_URL

engine = create_async_engine(DATABASE_URL, echo=False)
Session = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)


class Base(DeclarativeBase):
    pass


class Profession(Base):
    __tablename__ = "professions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    title: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    description: Mapped[str] = mapped_column(Text)
    skills: Mapped[str] = mapped_column(Text)       # JSON-массив
    interests: Mapped[str] = mapped_column(Text)    # JSON-массив
    work_style: Mapped[str] = mapped_column(String(80), default="любой")
    education: Mapped[str] = mapped_column(Text, default="Зависит от работодателя")
    tags: Mapped[str] = mapped_column(Text, default="")


class UserProfile(Base):
    __tablename__ = "user_profiles"

    telegram_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(120), default="")
    interests: Mapped[str] = mapped_column(Text, default="[]")
    strengths: Mapped[str] = mapped_column(Text, default="[]")
    work_style: Mapped[str] = mapped_column(String(80), default="не важно")
    updated_at: Mapped[str] = mapped_column(String(40), default="")


class Favorite(Base):
    __tablename__ = "favorites"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    telegram_id: Mapped[int] = mapped_column(Integer, index=True)
    profession_id: Mapped[int] = mapped_column(ForeignKey("professions.id"))


class ChatMessage(Base):
    __tablename__ = "chat_messages"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    telegram_id: Mapped[int] = mapped_column(Integer, index=True)
    role: Mapped[str] = mapped_column(String(20))
    content: Mapped[str] = mapped_column(Text)
    created_at: Mapped[str] = mapped_column(String(40), index=True)


class UserMemory(Base):
    __tablename__ = "user_memories"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    telegram_id: Mapped[int] = mapped_column(Integer, index=True)
    content: Mapped[str] = mapped_column(Text)
    category: Mapped[str] = mapped_column(String(40), default="fact")
    importance: Mapped[int] = mapped_column(Integer, default=3)
    created_at: Mapped[str] = mapped_column(String(40))
    updated_at: Mapped[str] = mapped_column(String(40))




class AISetting(Base):
    """Глобальные настройки ИИ, доступные только владельцу через панель."""
    __tablename__ = "ai_settings"

    key: Mapped[str] = mapped_column(String(100), primary_key=True)
    value: Mapped[str] = mapped_column(Text, default="")


async def get_ai_setting(key: str, default: str = "") -> str:
    async with Session() as session:
        item = await session.get(AISetting, key)
        return item.value if item else default


async def set_ai_setting(key: str, value: str) -> None:
    async with Session() as session:
        item = await session.get(AISetting, key)
        if item is None:
            item = AISetting(key=key, value=value)
            session.add(item)
        else:
            item.value = value
        await session.commit()


# Названия интересов и навыков лучше повторять в одном и том же виде:
# это повышает качество простого алгоритма персональных рекомендаций.
def load_professions():
    """Загружает каталог из простого JSON-файла рядом с этим модулем."""
    from pathlib import Path

    data_path = Path(__file__).with_name("professions.json")
    with data_path.open("r", encoding="utf-8") as file:
        data = json.load(file)
    if not isinstance(data, list):
        raise ValueError("professions.json должен содержать список профессий")
    return data



async def init_db():
    """Создаёт таблицы и синхронизирует демо-каталог с professions.json."""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    catalog = load_professions()
    async with Session() as session:
        existing = {p.title: p for p in (await session.scalars(select(Profession))).all()}
        changed = False

        # Удаляем из старой локальной базы три заменённые карточки каталога,
        # чтобы после обновления там не оставались устаревшие профессии.
        removed_titles = {
            "Военнослужащий по контракту",
            "Офицер вооружённых сил",
            "Участковый уполномоченный полиции",
        }
        for title in removed_titles:
            obsolete = existing.pop(title, None)
            if obsolete is None:
                continue
            await session.execute(
                delete(Favorite).where(Favorite.profession_id == obsolete.id)
            )
            await session.execute(
                delete(Profession).where(Profession.id == obsolete.id)
            )
            changed = True

        for item in catalog:
            required = {"title", "description", "skills", "interests", "work_style", "education", "tags"}
            if not isinstance(item, dict) or not required.issubset(item):
                continue
            profession = existing.get(item["title"])
            if profession is None:
                profession = Profession(title=item["title"])
                session.add(profession)
                existing[item["title"]] = profession
            profession.description = item["description"]
            profession.skills = json.dumps(item["skills"], ensure_ascii=False)
            profession.interests = json.dumps(item["interests"], ensure_ascii=False)
            profession.work_style = item["work_style"]
            profession.education = item["education"]
            profession.tags = item["tags"]
            changed = True
        if changed:
            await session.commit()
