"""Долговременная память и журнал диалогов для Telegram-ассистента."""
from __future__ import annotations

import re
from datetime import datetime, timezone

from sqlalchemy import select, desc, func

from database import Session, ChatMessage, UserMemory


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


async def save_message(telegram_id: int, role: str, content: str) -> None:
    async with Session() as session:
        session.add(ChatMessage(telegram_id=telegram_id, role=role, content=content[:12000], created_at=_now()))
        await session.commit()


async def count_user_messages(telegram_id: int) -> int:
    async with Session() as session:
        value = await session.scalar(
            select(func.count(ChatMessage.id)).where(
                ChatMessage.telegram_id == telegram_id, ChatMessage.role == "user"
            )
        )
    return int(value or 0)


async def load_history(telegram_id: int, limit: int = 18) -> list[dict[str, str]]:
    async with Session() as session:
        rows = (await session.scalars(
            select(ChatMessage).where(ChatMessage.telegram_id == telegram_id)
            .order_by(desc(ChatMessage.id)).limit(limit)
        )).all()
    return [{"role": row.role, "content": row.content} for row in reversed(rows)]


def _terms(text: str) -> set[str]:
    return {w.lower() for w in re.findall(r"[a-zа-яё0-9]{3,}", text, flags=re.I)}


async def load_memories(telegram_id: int, query: str = "", limit: int = 30) -> list[UserMemory]:
    async with Session() as session:
        rows = (await session.scalars(
            select(UserMemory).where(UserMemory.telegram_id == telegram_id)
            .order_by(desc(UserMemory.importance), desc(UserMemory.updated_at)).limit(250)
        )).all()
    if not query:
        return rows[:limit]
    terms = _terms(query)
    ranked = sorted(rows, key=lambda m: (len(terms & _terms(m.content)), m.importance), reverse=True)
    relevant = [m for m in ranked if terms & _terms(m.content)]
    return (relevant or rows)[:limit]


async def remember(telegram_id: int, content: str, category: str = "fact", importance: int = 3) -> bool:
    content = " ".join(content.strip().split())[:1000]
    if len(content) < 3:
        return False
    async with Session() as session:
        existing = (await session.scalars(
            select(UserMemory).where(UserMemory.telegram_id == telegram_id, UserMemory.content == content)
        )).first()
        if existing:
            existing.updated_at = _now()
            existing.importance = max(existing.importance, min(5, max(1, importance)))
        else:
            session.add(UserMemory(telegram_id=telegram_id, content=content, category=category[:40],
                                   importance=min(5, max(1, importance)), created_at=_now(), updated_at=_now()))
        await session.commit()
    return True


async def delete_memories(telegram_id: int) -> int:
    from sqlalchemy import delete
    async with Session() as session:
        rows = (await session.scalars(select(UserMemory).where(UserMemory.telegram_id == telegram_id))).all()
        count = len(rows)
        for row in rows:
            await session.delete(row)
        await session.commit()
        return count


async def clear_history(telegram_id: int) -> int:
    from sqlalchemy import delete
    async with Session() as session:
        result = await session.execute(delete(ChatMessage).where(ChatMessage.telegram_id == telegram_id))
        await session.commit()
        return result.rowcount or 0
